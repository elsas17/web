# Edu Account creator

## How to use?
1. Install Firefox (https://www.mozilla.org/en-US/firefox/new/)
2. Download Geckodriver (https://github.com/mozilla/geckodriver/releases)

## Why should i need it?

With this tool you can generate many studentmails (.edu mail) 

For those who might not know the benefits of edu email: 

1. Free amazon prime for 6 months
2. Unlimited Google Drive (most useful of pirates like you and me)
3. Google apps for education
4. Discounted Adobe CC
5. Microsoft dreamspark
6. Autodesk software's
7. Github student developer pack
8. Mindsumo
9. Office 365
10. Apple music 50% off
11. Spotify 50% off
12. Discounts on Dell products
13. Discounts on Lenevo products
